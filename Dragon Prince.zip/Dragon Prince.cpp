#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

class Item {
public:
    Item(const std::string& name) : name(name) {}
    virtual void use() = 0;

protected:
    std::string name;
};

class HealthPotion : public Item {
public:
    HealthPotion() : Item("Health Potion") {}

    void use() override {
        std::cout << "You drink the health potion and feel rejuvenated!\n";
    }
};

class Weapon : public Item {
public:
    Weapon(const std::string& name, int damage) : Item(name), damage(damage) {}

    void use() override {
        std::cout << "You wield the " << name << " and prepare for battle!\n";
    }

    int getDamage() const {
        return damage;
    }

private:
    int damage;
};

class Room {
public:
    Room(const std::string& description) : description(description) {}

    void setDescription(const std::string& desc) {
        description = desc;
    }

    void addOption(const std::string& option, int nextRoomIndex) {
        options.push_back(std::make_pair(option, nextRoomIndex));
    }

    int getOptionsCount() const {
        return options.size();
    }

    int getNextRoomIndex(int choice) const {
        if (choice >= 0 && choice < options.size()) {
            return options[choice].second;
        }
        return -1;
    }

    void displayOptions() const {
        std::cout << "Choose your next move:\n";
        for (int i = 0; i < options.size(); ++i) {
            std::cout << i + 1 << ". " << options[i].first << "\n";
        }
    }

    void displayDescription() const {
        std::cout << description << "\n";
    }

private:
    std::string description;
    std::vector<std::pair<std::string, int>> options;
};

class Player {
public:
    void addItem(Item* item) {
        inventory.push_back(item);
    }

    void useItem(int index) {
        if (index >= 0 && index < inventory.size()) {
            inventory[index]->use();
            delete inventory[index];
            inventory.erase(inventory.begin() + index);
        }
    }

    void equipWeapon(Weapon* weapon) {
        equippedWeapon = weapon;
        equippedWeapon->use();
    }

    int getEquippedWeaponDamage() const {
        return equippedWeapon ? equippedWeapon->getDamage() : 0;
    }

private:
    std::vector<Item*> inventory;
    Weapon* equippedWeapon = nullptr;
};

class Game {
public:
    Game() {
        // Initialize rooms
        rooms.push_back(Room("You find yourself in a dimly lit cave. There are two tunnels ahead."));
        rooms.push_back(Room("You enter a room with a strange inscription on the wall."));
        rooms.push_back(Room("You step into a room filled with sparkling gems."));
        rooms.push_back(Room("You encounter a menacing dragon!"));

        // Define room options
        rooms[0].addOption("Take the left tunnel", 1);
        rooms[0].addOption("Take the right tunnel", 2);
        rooms[1].addOption("Read the inscription", 2);
        rooms[1].addOption("Search for a way out", 0);
        rooms[2].addOption("Collect the gems", 3);
        rooms[2].addOption("Leave the gems and explore further", 0);
        rooms[3].addOption("Fight the dragon with your bare hands", -1); // Game over
        rooms[3].addOption("Use your equipped weapon", 2); // Back to the gem room
    }

    void start() {
        int currentRoomIndex = 0;
        Player player;

        while (currentRoomIndex >= 0) {
            Room& currentRoom = rooms[currentRoomIndex];

            std::cout << "\n---\n";
            currentRoom.displayDescription();
            currentRoom.displayOptions();

            int choice;
            std::cin >> choice;
            --choice; // Adjust for 0-based indexing

            if (choice >= 0 && choice < currentRoom.getOptionsCount()) {
                currentRoomIndex = currentRoom.getNextRoomIndex(choice);

                if (currentRoomIndex == 2) {
                    // Special case: entering the gem room
                    std::cout << "You find a shiny sword on the ground. You equip it.\n";
                    player.equipWeapon(new Weapon("Shiny Sword", 20));
                } else if (currentRoomIndex == -1) {
                    // Special case: game over
                    std::cout << "The dragon's flames consume you. Game over!\n";
                    break;
                } else if (currentRoomIndex == 3) {
                    // Special case: dragon encounter
                    int playerDamage = player.getEquippedWeaponDamage();
                    if (playerDamage > 0) {
                        std::cout << "You face the dragon in battle...\n";
                        std::cout << "You strike the dragon and defeat it! Congratulations, you win!\n";
                    } else {
                        std::cout << "You bravely attack the dragon with your bare hands...\n";
                        std::cout << "Unfortunately, the dragon's flames overpower you. Game over!\n";
                    }
                    break;
                }
            } else {
                std::cout << "Invalid choice. Try again.\n";
            }
        }
    }

private:
    std::vector<Room> rooms;
};

int main() {
    Game game;
    game.start();
    return 0;
}
